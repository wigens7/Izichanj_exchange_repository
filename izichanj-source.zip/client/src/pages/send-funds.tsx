import { useState } from "react";
import { formatDate } from "@/lib/dateUtils";
import { useUser } from "@/hooks/use-auth";
import { useLanguage } from "@/lib/i18n";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatUsdt, formatHtg } from "@shared/constants";
import { useRates } from "@/hooks/use-rates";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, Search, Send, ArrowUpRight, ArrowDownLeft, ShieldAlert, CheckCircle2, User, Receipt } from "lucide-react";

interface RecipientInfo {
  id: number;
  fullName: string;
  referenceId: string;
  email: string;
}

interface TransferRecord {
  id: number;
  senderProfileId: number;
  receiverProfileId: number;
  amount: string;
  note: string | null;
  createdAt: string;
  transactionId: string | null;
  receiptId: string | null;
  senderName: string;
  receiverName: string;
  direction: "sent" | "received";
}

export default function SendFundsPage() {
  const { data: user } = useUser();
  const { t } = useLanguage();
  const { toast } = useToast();
  const { depositRate } = useRates();

  const [identifier, setIdentifier] = useState("");
  const [recipient, setRecipient] = useState<RecipientInfo | null>(null);
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [receiptTr, setReceiptTr] = useState<TransferRecord | null>(null);

  const { data: transfers = [], isLoading: loadingHistory } = useQuery<TransferRecord[]>({
    queryKey: ["/api/transfers"],
  });

  const lookupMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("POST", "/api/transfers/lookup", { identifier: id });
      return res.json();
    },
    onSuccess: (data: RecipientInfo) => {
      setRecipient(data);
    },
    onError: () => {
      setRecipient(null);
      toast({ title: t.transfer.userNotFound, variant: "destructive" });
    },
  });

  const sendMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/transfers/send", {
        recipientId: recipient!.id,
        amount: parseFloat(amount).toFixed(2),
        note: note || undefined,
      });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: t.transfer.success, description: t.transfer.successDesc });
      setRecipient(null);
      setIdentifier("");
      setAmount("");
      setNote("");
      queryClient.invalidateQueries({ queryKey: ["/api/transfers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (err: any) => {
      let msg = "Error";
      try {
        const jsonPart = err.message?.split(": ").slice(1).join(": ");
        const parsed = JSON.parse(jsonPart);
        msg = parsed.message || msg;
      } catch {
        msg = err.message || msg;
      }
      toast({ title: msg, variant: "destructive" });
    },
  });

  if (!user) return null;

  const isKycVerified = user.kycStatus === "verified";
  const balance = parseFloat(user.balance);
  const parsedAmount = parseFloat(amount);
  const isValidAmount = !isNaN(parsedAmount) && parsedAmount >= 1 && parsedAmount <= balance;

  if (!isKycVerified) {
    return (
      <div className="space-y-6 animate-in fade-in duration-300">
        <div>
          <h1 className="text-2xl font-display font-bold">{t.transfer.title}</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{t.transfer.subtitle}</p>
        </div>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-10">
              <div className="w-14 h-14 rounded-md bg-amber-500/10 flex items-center justify-center mx-auto mb-4">
                <ShieldAlert className="w-7 h-7 text-amber-600 dark:text-amber-400" />
              </div>
              <h3 className="text-lg font-bold text-amber-700 dark:text-amber-400">{t.transfer.kycRequired}</h3>
              <p className="text-sm text-muted-foreground mt-2 max-w-md mx-auto">{t.transfer.kycRequiredDesc}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div>
        <h1 className="text-2xl font-display font-bold">{t.transfer.title}</h1>
        <p className="text-sm text-muted-foreground mt-0.5">{t.transfer.subtitle}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Send className="w-5 h-5 text-primary" />
                <CardTitle className="text-base">{t.transfer.title}</CardTitle>
              </div>
              <CardDescription className="text-xs">{t.transfer.subtitle}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="space-y-2">
                <Label className="text-sm">{t.transfer.recipientLabel}</Label>
                <div className="flex gap-2">
                  <Input
                    value={identifier}
                    onChange={(e) => {
                      setIdentifier(e.target.value);
                      if (recipient) setRecipient(null);
                    }}
                    placeholder={t.transfer.recipientPlaceholder}
                    data-testid="input-transfer-identifier"
                  />
                  <Button
                    onClick={() => lookupMutation.mutate(identifier.trim())}
                    disabled={!identifier.trim() || lookupMutation.isPending}
                    data-testid="button-lookup-recipient"
                  >
                    {lookupMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Search className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>

              {recipient && (
                <div className="rounded-md bg-emerald-500/5 border border-emerald-200 dark:border-emerald-800/50 p-4" data-testid="recipient-found-card">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-md bg-emerald-500/10 flex items-center justify-center">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-emerald-700 dark:text-emerald-400">{t.transfer.recipientFound}</p>
                      <p className="text-sm" data-testid="text-recipient-name">{recipient.fullName}</p>
                      <p className="text-xs text-muted-foreground" data-testid="text-recipient-email">{recipient.email}</p>
                    </div>
                  </div>
                </div>
              )}

              {recipient && (
                <>
                  <div className="space-y-2">
                    <Label className="text-sm">{t.transfer.amount}</Label>
                    <Input
                      type="number"
                      step="0.01"
                      min="1"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder={t.transfer.amountPlaceholder}
                      data-testid="input-transfer-amount"
                    />
                    <div className="flex items-center justify-between flex-wrap gap-1">
                      <p className="text-xs text-muted-foreground">{t.transfer.minAmount}</p>
                      {parsedAmount > 0 && (
                        <p className="text-xs text-muted-foreground">
                          ~ {formatHtg(parsedAmount * depositRate)} HTG
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm">{t.transfer.note}</Label>
                    <Input
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder={t.transfer.notePlaceholder}
                      maxLength={200}
                      data-testid="input-transfer-note"
                    />
                  </div>

                  <Button
                    className="w-full primary-gradient"
                    disabled={!isValidAmount || sendMutation.isPending}
                    onClick={() => sendMutation.mutate()}
                    data-testid="button-send-funds"
                  >
                    {sendMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        {t.transfer.sending}
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        {t.transfer.sendButton}
                      </>
                    )}
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-[11px] uppercase tracking-wider text-muted-foreground mb-1">{t.transfer.yourBalance}</p>
                <p className="text-2xl font-display font-bold" data-testid="text-transfer-balance">{formatUsdt(balance)} <span className="text-sm font-normal text-muted-foreground">USDT</span></p>
                <p className="text-sm text-muted-foreground mt-0.5">{formatHtg(balance * depositRate)} HTG</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">{t.transfer.history}</CardTitle>
        </CardHeader>
        <CardContent>
          {loadingHistory ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : transfers.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground text-sm" data-testid="text-no-transfers">
              {t.transfer.noTransfers}
            </div>
          ) : (
            <div className="space-y-2">
              {transfers.map((tr) => (
                <div
                  key={tr.id}
                  className="flex items-center gap-3 p-3 rounded-md border border-border"
                  data-testid={`transfer-row-${tr.id}`}
                >
                  <div className={`w-9 h-9 rounded-md flex items-center justify-center ${
                    tr.direction === "sent"
                      ? "bg-red-500/10 text-red-600 dark:text-red-400"
                      : "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                  }`}>
                    {tr.direction === "sent" ? (
                      <ArrowUpRight className="w-4 h-4" />
                    ) : (
                      <ArrowDownLeft className="w-4 h-4" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant={tr.direction === "sent" ? "destructive" : "default"}>
                        {tr.direction === "sent" ? t.transfer.sent : t.transfer.received}
                      </Badge>
                      <span className="text-sm">
                        {tr.direction === "sent"
                          ? `${t.transfer.to} ${tr.receiverName}`
                          : `${t.transfer.from} ${tr.senderName}`}
                      </span>
                    </div>
                    {tr.note && <p className="text-xs text-muted-foreground mt-0.5 truncate">{tr.note}</p>}
                    <p className="text-[11px] text-muted-foreground mt-0.5 font-mono" data-testid={`text-transfer-id-${tr.id}`}>
                      ID: {tr.transactionId || `IZ${String(tr.id).padStart(10, "0")}`}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className={`text-sm font-bold ${
                      tr.direction === "sent"
                        ? "text-red-600 dark:text-red-400"
                        : "text-emerald-600 dark:text-emerald-400"
                    }`}>
                      {tr.direction === "sent" ? "-" : "+"}{formatUsdt(parseFloat(tr.amount))} USDT
                    </p>
                    <p className="text-[11px] text-muted-foreground">
                      {formatDate(tr.createdAt)}
                    </p>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setReceiptTr(tr)}
                      title={t.transfer.receipt}
                      data-testid={`button-transfer-receipt-${tr.id}`}
                      className="h-7 px-2 mt-1.5 gap-1 text-[11px] border-indigo-500/40 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40"
                    >
                      <Receipt className="w-3 h-3" />
                      {t.transfer.receipt}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={receiptTr !== null} onOpenChange={(o) => !o && setReceiptTr(null)}>
        <DialogContent className="max-w-sm" data-testid="dialog-transfer-receipt">
          <DialogHeader>
            <DialogTitle className="sr-only">{t.transfer.receipt}</DialogTitle>
          </DialogHeader>
          {receiptTr && (
            <div className="space-y-5">
              <div className="flex flex-col items-center text-center gap-2 pt-1">
                <div className="w-14 h-14 rounded-full bg-emerald-500/10 flex items-center justify-center">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500" />
                </div>
                <p className={`text-2xl font-bold ${
                  receiptTr.direction === "sent"
                    ? "text-red-600 dark:text-red-400"
                    : "text-emerald-600 dark:text-emerald-400"
                }`} data-testid="text-receipt-amount">
                  {receiptTr.direction === "sent" ? "-" : "+"}{formatUsdt(parseFloat(receiptTr.amount))} USDT
                </p>
                <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/15">
                  {t.transfer.completed}
                </Badge>
              </div>

              <div className="divide-y divide-border rounded-lg border border-border overflow-hidden">
                {([
                  [t.transfer.receiptType, t.transfer.p2pTransfer],
                  [t.transfer.amount, `${formatUsdt(parseFloat(receiptTr.amount))} USDT`],
                  [t.transfer.fee, "0.00 USDT"],
                  [t.transfer.sender, receiptTr.senderName],
                  [t.transfer.recipient, receiptTr.receiverName],
                  [t.transfer.network, "Izichanj Internal"],
                  ...(receiptTr.note ? [[t.transfer.note, receiptTr.note]] : []),
                  [t.transfer.date, formatDate(receiptTr.createdAt)],
                  ["ID", receiptTr.transactionId || `IZ${String(receiptTr.id).padStart(10, "0")}`],
                ] as [string, string][]).map(([label, value], i) => (
                  <div key={i} className="flex items-start justify-between gap-3 px-3 py-2.5 text-sm">
                    <span className="text-muted-foreground shrink-0">{label}</span>
                    <span className="font-medium text-right break-all" data-testid={`text-receipt-${i}`}>{value}</span>
                  </div>
                ))}
              </div>

              <Button
                variant="outline"
                className="w-full"
                onClick={() => setReceiptTr(null)}
                data-testid="button-close-receipt"
              >
                {t.transfer.close}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
